// sources:
//      stoi: https://www.geeksforgeeks.org/cpp/convert-string-to-int-in-cpp/ Accessed 11/8/25


#include <pthread.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h>
#include <semaphore.h>
#include <string>
#include "bathroom.h"

using namespace std;

int main(int argc, char **argv) {
    bathMax = 4;
    bathroom = createBathroom(bathroom, bathMax);

    pthread_t elfThreads[5], dwarfThreads[5];
    pthread_attr_t attr;
    pthread_attr_init(&attr);

    sem_init(&bath_mutex, 0, 1);
    sem_init(&species_mutex, 0, 1);

    //create multiple elves and multiple dwarves 
    for (int i = 0; i < 5; i++) {
        pthread_create(&elfThreads[i], &attr, elves, NULL);
        pthread_create(&dwarfThreads[i], &attr, dwarves, NULL);
    }

    for (int i = 0; i < 5; i++) {
        pthread_join(elfThreads[i], NULL);
        pthread_join(dwarfThreads[i], NULL);
    }
}

Bathroom createBathroom(Bathroom bathroom, int bathMax){
    bathroom.currerntSpecies = "NONE";
    bathroom.countInBath = 0;
    bathroom.bathMax = bathMax;
    return bathroom;
}

void *elves(void *param){
    printf("Elf Ready\n");
    while (true) {
    //enter the bathroom
    sem_wait(&bath_mutex); 

    if (bathroom.currerntSpecies == "NONE") {
        bathroom.currerntSpecies = "ELF";
        sem_wait(&species_mutex); 
    } else if (bathroom.currerntSpecies != "ELF") {
        sem_post(&bath_mutex);
        sem_wait(&species_mutex);
        sem_wait(&bath_mutex);
        bathroom.currerntSpecies = "ELF";
    }

    if (bathroom.countInBath < bathroom.bathMax) {
        bathroom.countInBath++;
        printf("ELF entered bathroom (%d inside)\n", bathroom.countInBath);
    }

    sem_post(&bath_mutex);

    //wait 
    sleep(2);

    //leave bathroom
    sem_wait(&bath_mutex);

    bathroom.countInBath--;
    printf("ELF left bathroom (%d remaining)\n",  bathroom.countInBath);

    if (bathroom.countInBath == 0) {
        bathroom.currerntSpecies = "NONE";
        sem_post(&species_mutex); 
    }
    sem_post(&bath_mutex);
    }
}
void *dwarves(void *param){
    printf("Dwarf Ready\n");
    while (true) {
        //enter the bathroom
    sem_wait(&bath_mutex); 

    if (bathroom.currerntSpecies == "NONE") {
        bathroom.currerntSpecies = "DWARF";
        sem_wait(&species_mutex); 
    } else if (bathroom.currerntSpecies != "DWARF") {
        sem_post(&bath_mutex);
        sem_wait(&species_mutex);
        sem_wait(&bath_mutex);
        bathroom.currerntSpecies = "DWARF";
    }

    if (bathroom.countInBath < bathroom.bathMax) {
        bathroom.countInBath++;
        printf("DWARF entered bathroom (%d inside)\n", bathroom.countInBath);
    }

    sem_post(&bath_mutex);

    //wait 
    sleep(2);

    //leave bathroom
    sem_wait(&bath_mutex);

    bathroom.countInBath--;
    printf("DWARF left bathroom (%d remaining)\n",  bathroom.countInBath);

    if (bathroom.countInBath == 0) {
        bathroom.currerntSpecies = "NONE";
        sem_post(&species_mutex); 
    }
    sem_post(&bath_mutex);
    }
}
